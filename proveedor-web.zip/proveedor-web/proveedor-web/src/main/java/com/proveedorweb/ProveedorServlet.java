package com.proveedorweb; // Paquete del servlet
import com.proveedorweb.dao.ProveedorDao; // Importa el DAO
import com.proveedorweb.model.Proveedor; // Importa el modelo

import jakarta.servlet.ServletException; // Excepciones del servlet
import jakarta.servlet.annotation.WebServlet; // Anotación para mapear la URL
import jakarta.servlet.http.HttpServlet; // Clase base de todo servlet
import jakarta.servlet.http.HttpServletRequest; // Representa la petición
import jakarta.servlet.http.HttpServletResponse; // Representa la respuesta

import java.io.IOException;
import java.util.List;

@WebServlet("/proveedores") // Este servlet responde a la URL /proveedores
public class ProveedorServlet extends HttpServlet {

    private ProveedorDao proveedorDao = new ProveedorDao(); // Instancia del DAO, reutilizable

    // Maneja las peticiones GET (consultas, como "listar")
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String accion = request.getParameter("accion"); // Lee el parámetro "accion" de la URL

        if ("listar".equals(accion)) { // Si la acción es listar
            List<Proveedor> proveedores = proveedorDao.listarProveedores(); // Consulta la BD
            request.setAttribute("proveedores", proveedores); // Guarda la lista para la JSP
            request.getRequestDispatcher("resultado.jsp").forward(request, response); // Reenvía a la JSP
        } else {
            response.sendRedirect("index.html"); // Si no hay acción válida, vuelve al formulario
        }
    }

    // Maneja las peticiones POST (envío de datos, como "insertar")
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String accion = request.getParameter("accion"); // Lee el parámetro "accion" del formulario

        if ("insertar".equals(accion)) { // Si la acción es insertar

            String nombre = request.getParameter("nombre"); // Lee cada campo del formulario
            String contacto = request.getParameter("contacto");
            String telefono = request.getParameter("telefono");
            String direccion = request.getParameter("direccion");

            Proveedor nuevoProveedor = new Proveedor(nombre, contacto, telefono, direccion); // Constructor sin id
            proveedorDao.insertarProveedor(nuevoProveedor); // Inserta en la BD

            response.sendRedirect("proveedores?accion=listar"); // Redirige a listar (para ver el resultado)
        }
    }
}
