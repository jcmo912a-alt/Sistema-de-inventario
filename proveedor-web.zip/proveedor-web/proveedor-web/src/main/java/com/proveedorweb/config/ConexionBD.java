package com.proveedorweb.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionBD {

    private static final String URL = "jdbc:mysql://localhost:3306/mydb";
    private static final String USUARIO = "root";
    private static final String CLAVE = "3212128889/js"; // verifica que sea tu clave real

    public static Connection obtenerConexion() {

        Connection conexion = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); // Fuerza el registro del driver de MySQL
            conexion = DriverManager.getConnection(URL, USUARIO, CLAVE);

        } catch (ClassNotFoundException e) { // Captura si no encuentra la clase del driver
            System.out.println("Driver de MySQL no encontrado: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("Error al conectar con la base de datos: " + e.getMessage());
        }

        return conexion;
    }
}