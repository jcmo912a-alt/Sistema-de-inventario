<%@ page contentType="text/html; charset=UTF-8" %> <%-- Define el tipo de contenido y codificación --%>
<%@ page import="com.proveedorweb.model.Proveedor" %> <%-- Importa la clase Proveedor --%>
<%@ page import="java.util.List" %> <%-- Importa List --%>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Proveedores registrados</title>
</head>
<body>
    <h1>Proveedores registrados</h1>

    <table border="1" cellpadding="5">
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Contacto</th>
            <th>Teléfono</th>
            <th>Dirección</th>
        </tr>

        <% // Bloque de código Java (scriptlet) dentro de la JSP
            List<Proveedor> proveedores = (List<Proveedor>) request.getAttribute("proveedores"); // Recupera la lista enviada por el servlet
            for (Proveedor p : proveedores) { // Recorre cada proveedor
        %>
        <tr>
            <td><%= p.getIdProveedor() %></td>
            <td><%= p.getNombre() %></td>
            <td><%= p.getContacto() %></td>
            <td><%= p.getTelefono() %></td>
            <td><%= p.getDireccion() %></td>
        </tr>
        <% } %>
    </table>

    <br>
    <a href="index.html">Volver al formulario</a>
</body>
</html>
